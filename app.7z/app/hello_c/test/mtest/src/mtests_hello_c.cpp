
typedef int int32_t;

/***************** Includes ***************************************************/
/* standard libraries */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* other component PUBLIC header files */
#include "CppUTest/TestHarness.h"
#include "CppUTestExt/MockSupport.h"
//#include "CppUTest/SystemAssertPlugin.h"

/***************** C Includes Under Test **************************************/

extern "C" {
#include "test_01.h"
#include "test_02.h"
}

/***************** Defines ****************************************************/

/***************** Public Functions Definitions *******************************/

TEST_GROUP(hello_c) {

	void setup() {
		//CHECK( sdb_iudp_init() == RET_OK );
	}

	void teardown()	{
	}
};

TEST(hello_c, lib_01)
{
	CHECK(30 == test_01(13) );
	CHECK(23 == test_01(3) );
//	CHECK(2 == test(3) );
//	CHECK(3 == test(3) );
}
TEST(hello_c, lib_02)
{
	CHECK(30 == test_02(13) );
	CHECK(23 == test_02(3) );
//	CHECK(2 == test(3) );
//	CHECK(3 == test(3) );
}

