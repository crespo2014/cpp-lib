/*
 * dllist.h
 *
 *  Created on: 6 Mar 2015
 *      Author: dragan
 */

#ifndef CDLLIST_H_
#define CDLLIST_H_

typedef struct node_t {
    node_t *next;
    node_t *prev;
    int data;
} node_t;



class Cdllist {
private:
    node_t *head;
    node_t *tail;
    friend class CdllistTest;

public:
    Cdllist();
    virtual ~Cdllist();
    node_t *CreateList(int data);
    node_t *AddToList(int data);
    node_t *SearchList(int data);
    int DeleteFromList(int data);
    void PrintList();
};

class CdllistTest {
public:
    CdllistTest() {};
    virtual ~CdllistTest() {};

    node_t *GetHead(Cdllist &a) {
        return a.head;
    }
    void SetHead(Cdllist &a, node_t *h) {
        a.head = h;
    }
    node_t *GetTail(Cdllist &a) {
        return a.tail;
    }
    void SetTail(Cdllist &a, node_t *h) {
        a.tail = h;
    }
};

#endif /* CDLLIST_H_ */
