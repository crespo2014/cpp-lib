/***************** Includes ***************************************************/
/* other component PUBLIC header files */
#include "CppUTest/TestHarness.h"
#include "CppUTestExt/MockSupport_c.h"
//#include "CppUTest/SystemAssertPlugin.h"

/* standard libraries */

/* C Includes Under Test */
#include "Cdllist.h"

/***************** Mocks ******************************************************/

/***************** Defines ****************************************************/

/***************** Public Functions Definitions *******************************/
TEST_GROUP(dllist) {

    void setup() {
    }

    void teardown()	{
    }
};


TEST(dllist, Cdllist)
{
    Cdllist l;
    CdllistTest t;
    POINTERS_EQUAL(t.GetHead(l), nullptr);
    POINTERS_EQUAL(t.GetTail(l), nullptr);
}
TEST(dllist, CreateList)
{
    node_t *p = nullptr;
    Cdllist l;
    CdllistTest t;

    // Code under the test - START
    p = l.CreateList(5);
    // Code under the test - STOP

    CHECK(p != nullptr);
    POINTERS_EQUAL(t.GetHead(l), p);
    POINTERS_EQUAL(t.GetTail(l), p);
    POINTERS_EQUAL(p->next, nullptr);
    POINTERS_EQUAL(p->prev, nullptr);
    POINTERS_EQUAL(p->data, 5);
}

TEST(dllist, AddToList)
{
    node_t *p[5];
    Cdllist l;
    CdllistTest t;

    // Code under the test - START
    p[0] = l.AddToList(5);
    // Code under the test - STOP
    CHECK(p[0] != nullptr);
    POINTERS_EQUAL(t.GetHead(l), p[0]);
    POINTERS_EQUAL(t.GetTail(l), p[0]);
    POINTERS_EQUAL(p[0]->prev, nullptr);
    POINTERS_EQUAL(p[0]->next, nullptr);
    POINTERS_EQUAL(p[0]->data, 5);
    // Code under the test - START
    p[1] = l.AddToList(6);
    // Code under the test - STOP
    CHECK(p[1] != nullptr);
    POINTERS_EQUAL(t.GetHead(l), p[0]);
    POINTERS_EQUAL(t.GetTail(l), p[1]);
    POINTERS_EQUAL(p[0]->prev, nullptr);
    POINTERS_EQUAL(p[0]->next, p[1]);
    POINTERS_EQUAL(p[0]->data, 5);
    POINTERS_EQUAL(p[1]->prev, p[0]);
    POINTERS_EQUAL(p[1]->next, nullptr);
    POINTERS_EQUAL(p[1]->data, 6);
    // Code under the test - START
    p[2] = l.AddToList(7);
    // Code under the test - STOP
    CHECK(p[2] != nullptr);
    POINTERS_EQUAL(t.GetHead(l), p[0]);
    POINTERS_EQUAL(t.GetTail(l), p[2]);
    POINTERS_EQUAL(p[0]->prev, nullptr);
    POINTERS_EQUAL(p[0]->next, p[1]);
    POINTERS_EQUAL(p[0]->data, 5);
    POINTERS_EQUAL(p[1]->prev, p[0]);
    POINTERS_EQUAL(p[1]->next, p[2]);
    POINTERS_EQUAL(p[1]->data, 6);
    POINTERS_EQUAL(p[2]->prev, p[1]);
    POINTERS_EQUAL(p[2]->next, nullptr);
    POINTERS_EQUAL(p[2]->data, 7);
    // Code under the test - START
    p[3] = l.AddToList(1);
    // Code under the test - STOP
    CHECK(p[3] != nullptr);
    POINTERS_EQUAL(t.GetHead(l), p[0]);
    POINTERS_EQUAL(t.GetTail(l), p[3]);
    POINTERS_EQUAL(p[0]->prev, nullptr);
    POINTERS_EQUAL(p[0]->next, p[1]);
    POINTERS_EQUAL(p[0]->data, 5);
    POINTERS_EQUAL(p[1]->prev, p[0]);
    POINTERS_EQUAL(p[1]->next, p[2]);
    POINTERS_EQUAL(p[1]->data, 6);
    POINTERS_EQUAL(p[2]->prev, p[1]);
    POINTERS_EQUAL(p[2]->next, p[3]);
    POINTERS_EQUAL(p[2]->data, 7);
    POINTERS_EQUAL(p[3]->prev, p[2]);
    POINTERS_EQUAL(p[3]->next, nullptr);
    POINTERS_EQUAL(p[3]->data, 1);
    // Code under the test - START
    p[4] = l.AddToList(3);
    // Code under the test - STOP
    CHECK(p[4] != nullptr);
    POINTERS_EQUAL(t.GetHead(l), p[0]);
    POINTERS_EQUAL(t.GetTail(l), p[4]);
    POINTERS_EQUAL(p[0]->prev, nullptr);
    POINTERS_EQUAL(p[0]->next, p[1]);
    POINTERS_EQUAL(p[0]->data, 5);
    POINTERS_EQUAL(p[1]->prev, p[0]);
    POINTERS_EQUAL(p[1]->next, p[2]);
    POINTERS_EQUAL(p[1]->data, 6);
    POINTERS_EQUAL(p[2]->prev, p[1]);
    POINTERS_EQUAL(p[2]->next, p[3]);
    POINTERS_EQUAL(p[2]->data, 7);
    POINTERS_EQUAL(p[3]->prev, p[2]);
    POINTERS_EQUAL(p[3]->next, p[4]);
    POINTERS_EQUAL(p[3]->data, 1);
    POINTERS_EQUAL(p[4]->prev, p[3]);
    POINTERS_EQUAL(p[4]->next, nullptr);
    POINTERS_EQUAL(p[4]->data, 3);
}


TEST(dllist, SearchList)
{
    node_t *p[5];
    Cdllist l;
    CdllistTest t;

    p[0] = l.AddToList(5);
    p[1] = l.AddToList(6);
    p[2] = l.AddToList(7);
    p[3] = l.AddToList(1);
    p[4] = l.AddToList(3);

    // Code under the test - START
    POINTERS_EQUAL(l.SearchList(5), p[0]);
    POINTERS_EQUAL(l.SearchList(7), p[2]);
    POINTERS_EQUAL(l.SearchList(3), p[4]);
    POINTERS_EQUAL(l.SearchList(2), nullptr);
    // Code under the test - STOP
}

TEST(dllist, DeleteFromList)
{
    node_t *p[5];
    Cdllist l;
    CdllistTest t;

    p[0] = l.AddToList(5);
    p[1] = l.AddToList(6);
    p[2] = l.AddToList(7);
    p[3] = l.AddToList(1);
    p[4] = l.AddToList(3);

    // Code under the test - START
    CHECK(l.DeleteFromList(11) == -1);
    // Code under the test - STOP

    // Code under the test - START
    CHECK(l.DeleteFromList(7) == 0);
    // Code under the test - STOP
    POINTERS_EQUAL(t.GetHead(l), p[0]);
    POINTERS_EQUAL(t.GetTail(l), p[4]);
    POINTERS_EQUAL(p[0]->prev, nullptr);
    POINTERS_EQUAL(p[0]->next, p[1]);
    POINTERS_EQUAL(p[0]->data, 5);
    POINTERS_EQUAL(p[1]->prev, p[0]);
    POINTERS_EQUAL(p[1]->next, p[3]);
    POINTERS_EQUAL(p[1]->data, 6);
    POINTERS_EQUAL(p[3]->prev, p[1]);
    POINTERS_EQUAL(p[3]->next, p[4]);
    POINTERS_EQUAL(p[3]->data, 1);
    POINTERS_EQUAL(p[4]->prev, p[3]);
    POINTERS_EQUAL(p[4]->next, nullptr);
    POINTERS_EQUAL(p[4]->data, 3);

    // Code under the test - START
    CHECK(l.DeleteFromList(5) == 0);
    // Code under the test - STOP
    POINTERS_EQUAL(t.GetHead(l), p[1]);
    POINTERS_EQUAL(t.GetTail(l), p[4]);
    POINTERS_EQUAL(p[1]->prev, nullptr);
    POINTERS_EQUAL(p[1]->next, p[3]);
    POINTERS_EQUAL(p[1]->data, 6);
    POINTERS_EQUAL(p[3]->prev, p[1]);
    POINTERS_EQUAL(p[3]->next, p[4]);
    POINTERS_EQUAL(p[3]->data, 1);
    POINTERS_EQUAL(p[4]->prev, p[3]);
    POINTERS_EQUAL(p[4]->next, nullptr);
    POINTERS_EQUAL(p[4]->data, 3);

    // Code under the test - START
    CHECK(l.DeleteFromList(3) == 0);
    // Code under the test - STOP
    POINTERS_EQUAL(t.GetHead(l), p[1]);
    POINTERS_EQUAL(t.GetTail(l), p[3]);
    POINTERS_EQUAL(p[1]->prev, nullptr);
    POINTERS_EQUAL(p[1]->next, p[3]);
    POINTERS_EQUAL(p[1]->data, 6);
    POINTERS_EQUAL(p[3]->prev, p[1]);
    POINTERS_EQUAL(p[3]->next, nullptr);
    POINTERS_EQUAL(p[3]->data, 1);

    // Code under the test - START
    CHECK(l.DeleteFromList(6) == 0);
    // Code under the test - STOP
    POINTERS_EQUAL(t.GetHead(l), p[3]);
    POINTERS_EQUAL(t.GetTail(l), p[3]);
    POINTERS_EQUAL(p[3]->prev, nullptr);
    POINTERS_EQUAL(p[3]->next, nullptr);
    POINTERS_EQUAL(p[3]->data, 1);

    // Code under the test - START
    CHECK(l.DeleteFromList(1) == 0);
    // Code under the test - STOP
    POINTERS_EQUAL(t.GetHead(l), nullptr);
    POINTERS_EQUAL(t.GetTail(l), nullptr);

    // Code under the test - START
    CHECK(l.DeleteFromList(1) == -1);
    // Code under the test - STOP

}

TEST(dllist, PrintList)
{
    Cdllist l;

    l.AddToList(5);
    l.AddToList(6);
    l.AddToList(7);
    l.AddToList(1);
    l.AddToList(3);

    // Code under the test - START
    l.PrintList();
    // Code under the test - STOP

}
