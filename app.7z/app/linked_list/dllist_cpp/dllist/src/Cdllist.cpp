/*
 * dllist.cpp
 *
 *  Created on: 6 Mar 2015
 *      Author: dragan
 */
#include <new>
#include <iostream>
#include "Cdllist.h"

//lint -A(C++2011)

using namespace std;

Cdllist::Cdllist() {
    head = nullptr;     //lint !e40
    tail = nullptr;     //lint !e40
}

Cdllist::~Cdllist() {
    node_t *p = tail;
    while(p != nullptr) {   //lint !e40
        p = tail->prev;
        delete tail;
        tail = p;
    }
    head = nullptr;     //lint !e40
    tail = nullptr;     //lint !e40
}   //lint !e1740

node_t *Cdllist::CreateList(int data)
{
    node_t *p;
    try {
        p = new node_t;
    } catch (const std::bad_alloc& e) {
        return nullptr;                //lint !e40
    }                                    //lint !e715
    p->data = data;
    p->next = nullptr;                  //lint !e40
    p->prev = nullptr;                  //lint !e40
    head = tail =p;
    return p;
}

node_t *Cdllist::AddToList(int data)
{
    if( head == nullptr) {              //lint !e40
        return CreateList(data);
    }

    node_t *p;
    try {
        p = new node_t;
    } catch (const std::bad_alloc& e) {
        return nullptr;                //lint !e40
    }                                    //lint !e715
    tail->next = p;
    p->data = data;
    p->next = nullptr;                  //lint !e40
    p->prev = tail;
    tail = p;
    return p;
}
node_t *Cdllist::SearchList(int data)
{
    node_t *p = head;
    while(p != nullptr) {   //lint !e40
        if(p->data == data) {
            return p;
        }
        p = p->next;
    }
    return nullptr; //lint !e40
}
int Cdllist::DeleteFromList(int data)
{
    node_t *p = SearchList(data);
    if(p == nullptr) {  //lint !e40
        return -1;
    }

    if((p->next == nullptr) && (p->prev == nullptr)) {  //lint !e40
        head = tail = nullptr;  //lint !e40
        delete p;
        return 0;
    }

    if(p->next == nullptr) {    //lint !e40
        p->prev->next = nullptr;    //lint !e40
        tail = p->prev;
    } else {
        p->next->prev = p->prev;
    }

    if(p->prev == nullptr) {    //lint !e40
        p->next->prev = nullptr;    //lint !e40
        head = p->next;
    } else {
        p->prev->next = p->next;
    }
    delete p;
    return 0;
}
void Cdllist::PrintList()
{
    node_t *tmp = head;
    int i=0;
    if(tmp == nullptr) {        //lint !e40
        return;
    }

    cout << "\n---------- List START -------------\n";
    while(tmp != nullptr) {     //lint !e40
        cout << i++ << ". data=" << tmp->data;
        cout << ", prev=" << tmp->prev;
        cout << ", current=" << tmp;
        cout << ", next=" << tmp->next << endl;
        tmp = tmp->next;
    }
    cout << "---------- List END ---------------\n";

}


