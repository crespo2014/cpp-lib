/**
 * @file linked_list.h
 *
 * @date 2 Mar 2015
 * @author dragan
 */

#ifndef APP_LINKED_LIST_CPP_INCLUDE_LINKED_LIST_H_
#define APP_LINKED_LIST_CPP_INCLUDE_LINKED_LIST_H_


class CNode {
public:
    int data;
    CNode *next;
};

class CLinkedList {
private:
    CNode *head;
    friend class CLinkedListTest;
public:
    CLinkedList();
    ~CLinkedList();
    CNode *CreateList(int val);
    CNode *AddToList(int val, bool add_to_end);
    CNode *SearchList(int val, CNode **prev);
    int DeleteFromList(int val);
    void PrintList(void);
};

class CLinkedListTest {
public:
    CNode *GetHead(CLinkedList &ll) {
        return ll.head;
    }
    void SetHead(CLinkedList &ll, CNode *a) {
        ll.head = a;
    }
};

#endif /* APP_LINKED_LIST_CPP_INCLUDE_LINKED_LIST_H_ */
