/*
 * Copyright (C) 2013 Dragan Cvetic. All rights reserved.
 *
 * This program is open source software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * Alternatively, this program may be distributed and modified under the
 * terms of Quantum Leaps commercial licenses, which expressly supersede
 * the GNU General Public License and are specifically designed for
 * licensees interested in retaining the proprietary status of their code.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Contact information:
 * --------------------
 * e-mail:      dragan.m.cvetic@gmail.com
 */
/*!
 * \file
 * \brief
 *      One line description of the file. Must make sense on it own
 *
 *      Continuation of the description into more detail if required.
 *
 * \version   0.0.1
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <pthread.h>
#include "linked_list.h"

static pthread_mutex_t mutex;

CNode *CLinkedList::CreateList(int data)
{
    CNode *ptr = new CNode;

    ptr->data = data;
    ptr->next = NULL;

    (void)pthread_mutex_lock(&mutex);
    CLinkedList::head = ptr;
    (void)pthread_mutex_unlock(&mutex);

    return ptr;
}

CNode *CLinkedList::AddToList(int data, bool add_to_end)
{
    if(head == NULL) {
        return CreateList(data);
    }

    CNode *ptr = new CNode;

    ptr->data = data;

    (void)pthread_mutex_lock(&mutex);
    if(add_to_end == true) {
        CNode *tmp=head;
        while(tmp->next != NULL) {
            tmp = tmp->next;
        }
        tmp->next = ptr;
        ptr->next = NULL;
    } else {
        ptr->next = head;
        head = ptr;
    }
    (void)pthread_mutex_unlock(&mutex);

    return ptr;
}

CNode *CLinkedList::SearchList(int data, CNode **prev)
{
    CNode *ptr = head, *tmp=NULL;
    *prev = NULL;

    if(ptr == NULL) {
//        printf("\nList does not exist\n");
        return NULL;
    }

    (void)pthread_mutex_lock(&mutex);
    while(ptr != NULL) {
        if(ptr->data == data) {
            *prev = tmp;
            (void)pthread_mutex_unlock(&mutex);
            return ptr;
        }
        tmp = ptr;
        ptr = ptr->next;
    }
    (void)pthread_mutex_unlock(&mutex);


    return NULL;
}

int CLinkedList::DeleteFromList(int data)
{
    CNode *prev=NULL, *del;

    (void)pthread_mutex_lock(&mutex);
    del = SearchList(data,&prev);

    if(del == NULL) {
        (void)pthread_mutex_unlock(&mutex);
        return -1;
    } else {
        if(prev != NULL) {
            prev->next = del->next;
        } else if(del == head) {
            head = head->next;
        }
    }
    (void)pthread_mutex_unlock(&mutex);

    delete del;
    return 0;
}

void CLinkedList::PrintList(void)
{
    CNode *tmp = head;
    int i=0;
    if(tmp == NULL) {
        return;
    }
    printf("\n---------- List START -------------\n");
    while(tmp != NULL) {
        printf("%d. data=%d, next=%llx\n", i++, tmp->data, (long long int)tmp->next);
        tmp = tmp->next;
    }
    printf("---------- List END ---------------\n");
}

CLinkedList::CLinkedList() {
    head = NULL;
}
CLinkedList::~CLinkedList() {
    while(head != NULL) {
        (void)CLinkedList::DeleteFromList(head->data);
    }
}
