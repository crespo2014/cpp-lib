/*
 *  Copyright (c) 2006-2012
 *  <Company Name> Ltd.
 *  All Rights Reserved
 *
 *  The information herein is confidential and proprietary.  Unauthorised
 *  disclosure or distribution is prohibited.
 */
/*!
 * \file
 * \brief
 *      One line description of the file. Must make sense on it own
 *
 *      Continuation of the description into more detail if required.
 *
 * \version   0.0.1
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>

#include "linked_list.h"

/*!
 * \brief
 *    One line description of the function. Must make sense on it own
 *
 *    Continuation of the description into more detail if required.
 *
 * \return  OK on success
 *          NOT_OK on failure
 */
int main(void)
{
    CLinkedList list;
    int i;
    for(i=0;i<10;i++) {
        printf("\n%d.\n",i);
        (void)list.AddToList(i,true);
        list.PrintList();
    }

    (void)list.DeleteFromList(4);
    list.PrintList();

	return EXIT_SUCCESS;
}
