
typedef int int32_t;

/***************** Includes ***************************************************/
/* standard libraries */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* other component PUBLIC header files */
#include "CppUTest/TestHarness.h"
#include "CppUTestExt/MockSupport.h"
//#include "CppUTest/SystemAssertPlugin.h"

/***************** C Includes Under Test **************************************/
#include "linked_list.h"

/***************** Defines ****************************************************/

/***************** Public Functions Definitions *******************************/

TEST_GROUP(linked_list) {

    void setup() {
    }

	void teardown()	{
	}
};

TEST(linked_list, llist_01)
{
//	CHECK(30 == test_01(13) );
//	CHECK(23 == test_01(3) );
//	CHECK(2 == test(3) );
//	CHECK(3 == test(3) );
}

