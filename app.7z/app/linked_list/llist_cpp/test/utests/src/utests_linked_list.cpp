/***************** Includes ***************************************************/
/* other component PUBLIC header files */
#include "CppUTest/TestHarness.h"
#include "CppUTestExt/MockSupport_c.h"
//#include "CppUTest/SystemAssertPlugin.h"

/* standard libraries */

/* C Includes Under Test */
#include "linked_list.h"

/***************** Mocks ******************************************************/

/***************** Defines ****************************************************/

/***************** Public Functions Definitions *******************************/
TEST_GROUP(linked_list) {

    void setup() {
    }

    void teardown()	{
    }
};

TEST(linked_list, CreateList)
{
    CNode *ptr=nullptr;
    CLinkedList l;
    CLinkedListTest t;

    ptr = l.CreateList(0);
    CHECK(ptr != nullptr);
    CHECK(ptr->data == 0);
    POINTERS_EQUAL(ptr, t.GetHead(l));
    l.PrintList();
}

TEST(linked_list, AddToList)
{
    CNode *ptr=nullptr, *tmp=nullptr;
    CLinkedList l;
    CLinkedListTest t;

    tmp = ptr = l.AddToList(0, true);
    CHECK(ptr != nullptr);
    CHECK(ptr->data == 0);
    POINTERS_EQUAL(ptr, t.GetHead(l));
    l.PrintList();

    ptr = l.AddToList(1, true);
    CHECK(ptr != nullptr);
    CHECK(ptr->data == 1);
    POINTERS_EQUAL(tmp, t.GetHead(l));
    l.PrintList();

    ptr = l.AddToList(2, true);
    CHECK(ptr != nullptr);
    CHECK(ptr->data == 2);
    POINTERS_EQUAL(tmp, t.GetHead(l));
    l.PrintList();

    ptr = l.AddToList(3, true);
    CHECK(ptr != nullptr);
    CHECK(ptr->data == 3);
    POINTERS_EQUAL(tmp, t.GetHead(l));
    l.PrintList();

    ptr = l.AddToList(4, true);
    CHECK(ptr != nullptr);
    CHECK(ptr->data == 4);
    POINTERS_EQUAL(tmp, t.GetHead(l));
    l.PrintList();

    ptr = l.AddToList(5, false);
    CHECK(ptr != nullptr);
    CHECK(ptr->data == 5);
    POINTERS_EQUAL(ptr, t.GetHead(l));
    l.PrintList();

    ptr = l.AddToList(6, false);
    CHECK(ptr != nullptr);
    CHECK(ptr->data == 6);
    POINTERS_EQUAL(ptr, t.GetHead(l));
    l.PrintList();

}


TEST(linked_list, SearchList)
{
    CLinkedList l;
    CNode *prev, *tmp[20];

    CHECK(nullptr == l.SearchList(0, &prev));    CHECK(nullptr == prev);

    tmp[0] = l.AddToList(0, true);
    tmp[1] = l.AddToList(1, true);
    tmp[2] = l.AddToList(2, true);
    tmp[3] = l.AddToList(3, true);
    tmp[4] = l.AddToList(4, true);
    tmp[5] = l.AddToList(5, false);
    tmp[6] = l.AddToList(6, false);
    l.PrintList();
    CHECK(tmp[0] == l.SearchList(0, &prev));  CHECK(tmp[5] == prev);
    CHECK(tmp[1] == l.SearchList(1, &prev));  CHECK(tmp[0] == prev);
    CHECK(tmp[2] == l.SearchList(2, &prev));  CHECK(tmp[1] == prev);
    CHECK(tmp[3] == l.SearchList(3, &prev));  CHECK(tmp[2] == prev);
    CHECK(tmp[4] == l.SearchList(4, &prev));  CHECK(tmp[3] == prev);
    CHECK(tmp[5] == l.SearchList(5, &prev));  CHECK(tmp[6] == prev);
    CHECK(tmp[6] == l.SearchList(6, &prev));  CHECK(nullptr == prev);
    CHECK(nullptr == l.SearchList(7, &prev));    CHECK(nullptr == prev);
}

TEST(linked_list, DeleteFromList)
{
    CLinkedList l;
    CLinkedListTest t;
    CNode *prev, *tmp[20];

    CHECK(-1 == l.DeleteFromList(0));

    tmp[0] = l.AddToList(0, true);
    tmp[1] = l.AddToList(1, true);
    tmp[2] = l.AddToList(2, true);
    tmp[3] = l.AddToList(3, true);
    tmp[4] = l.AddToList(4, true);
    tmp[5] = l.AddToList(5, false);
    tmp[6] = l.AddToList(6, false);
    l.PrintList();

    CHECK(-1 == l.DeleteFromList(7));

    CHECK(0 == l.DeleteFromList(0));
    CHECK(nullptr == l.SearchList(0, &prev));
    CHECK(nullptr == prev);
    CHECK(tmp[1] == l.SearchList(1, &prev)); CHECK(tmp[5] == prev);
    l.PrintList();

    CHECK(0 == l.DeleteFromList(4));
    CHECK(nullptr == l.SearchList(4, &prev));
    CHECK(nullptr == prev);
    l.PrintList();

    CHECK(0 == l.DeleteFromList(6));
    CHECK(nullptr == l.SearchList(6, &prev));
    CHECK(nullptr == prev);
    CHECK(t.GetHead(l) == l.SearchList(5, &prev));
    l.PrintList();

}
