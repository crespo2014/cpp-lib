/***************** Includes ***************************************************/
/* other component PUBLIC header files */
#include "CppUTest/TestHarness.h"
#include "CppUTestExt/MockSupport_c.h"
//#include "CppUTest/SystemAssertPlugin.h"

/* standard libraries */

/* C Includes Under Test */
extern "C" {
#include "linked_list.h"
#include <stdio.h>
}

/***************** Mocks ******************************************************/

/***************** Defines ****************************************************/

/***************** Public Functions Definitions *******************************/
TEST_GROUP(linked_list) {

    void setup() {
        set_head(NULL);
        set_current(NULL);
    }

    void teardown()	{
        mock_c()->clear();
    }
};
llist *ptr, *tmp;

TEST(linked_list, create_list)
{
    tmp = ptr = create_list(0);
    CHECK(ptr != NULL);
    CHECK(ptr->val == 0);
    POINTERS_EQUAL(ptr, get_head());
    POINTERS_EQUAL(ptr, get_current());
    print_list();
}

TEST(linked_list, add_to_list)
{
    tmp = ptr = add_to_list(0, true);
    CHECK(ptr != NULL);
    CHECK(ptr->val == 0);
    POINTERS_EQUAL(ptr, get_head());
    POINTERS_EQUAL(ptr, get_current());
    print_list();

    ptr = add_to_list(1, true);
    CHECK(ptr != NULL);
    CHECK(ptr->val == 1);
    POINTERS_EQUAL(tmp, get_head());
    POINTERS_EQUAL(ptr, get_current());
    print_list();

    ptr = add_to_list(2, true);
    CHECK(ptr != NULL);
    CHECK(ptr->val == 2);
    POINTERS_EQUAL(tmp, get_head());
    POINTERS_EQUAL(ptr, get_current());
    print_list();

    ptr = add_to_list(3, true);
    CHECK(ptr != NULL);
    CHECK(ptr->val == 3);
    POINTERS_EQUAL(tmp, get_head());
    POINTERS_EQUAL(ptr, get_current());
    print_list();

    ptr = add_to_list(4, true);
    CHECK(ptr != NULL);
    CHECK(ptr->val == 4);
    POINTERS_EQUAL(tmp, get_head());
    POINTERS_EQUAL(ptr, get_current());
    print_list();

    tmp = get_current();
    ptr = add_to_list(5, false);
    CHECK(ptr != NULL);
    CHECK(ptr->val == 5);
    POINTERS_EQUAL(ptr, get_head());
    POINTERS_EQUAL(tmp, get_current());
    print_list();

    ptr = add_to_list(6, false);
    CHECK(ptr != NULL);
    CHECK(ptr->val == 6);
    POINTERS_EQUAL(ptr, get_head());
    POINTERS_EQUAL(tmp, get_current());
    print_list();

}


TEST(linked_list, search_list)
{
    llist *prev, *tmp[20];

    CHECK(NULL == search_list(0, &prev));    CHECK(NULL == prev);

    tmp[0] = add_to_list(0, true);
    tmp[1] = add_to_list(1, true);
    tmp[2] = add_to_list(2, true);
    tmp[3] = add_to_list(3, true);
    tmp[4] = add_to_list(4, true);
    tmp[5] = add_to_list(5, false);
    tmp[6] = add_to_list(6, false);
    print_list();
    CHECK(tmp[0] == search_list(0, &prev));  CHECK(tmp[5] == prev);
    CHECK(tmp[1] == search_list(1, &prev));  CHECK(tmp[0] == prev);
    CHECK(tmp[2] == search_list(2, &prev));  CHECK(tmp[1] == prev);
    CHECK(tmp[3] == search_list(3, &prev));  CHECK(tmp[2] == prev);
    CHECK(tmp[4] == search_list(4, &prev));  CHECK(tmp[3] == prev);
    CHECK(tmp[5] == search_list(5, &prev));  CHECK(tmp[6] == prev);
    CHECK(tmp[6] == search_list(6, &prev));  CHECK(NULL == prev);
    CHECK(NULL == search_list(7, &prev));    CHECK(NULL == prev);
}

TEST(linked_list, delete_from_list)
{
    llist *prev, *tmp[20];

    CHECK(-1 == delete_from_list(0));

    tmp[0] = add_to_list(0, true);
    tmp[1] = add_to_list(1, true);
    tmp[2] = add_to_list(2, true);
    tmp[3] = add_to_list(3, true);
    tmp[4] = add_to_list(4, true);
    tmp[5] = add_to_list(5, false);
    tmp[6] = add_to_list(6, false);
    print_list();

    CHECK(-1 == delete_from_list(7));

    CHECK(0 == delete_from_list(0));
    CHECK(NULL == search_list(0, &prev));
    CHECK(NULL == prev);
    CHECK(tmp[1] == search_list(1, &prev)); CHECK(tmp[5] == prev);
    print_list();

    CHECK(0 == delete_from_list(4));
    CHECK(NULL == search_list(4, &prev));
    CHECK(NULL == prev);
    CHECK(get_current() == search_list(3, &prev));
    print_list();

    CHECK(0 == delete_from_list(6));
    CHECK(NULL == search_list(6, &prev));
    CHECK(NULL == prev);
    CHECK(get_head() == search_list(5, &prev));
    print_list();

}
