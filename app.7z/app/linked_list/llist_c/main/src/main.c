/*
 *  Copyright (c) 2006-2012
 *  <Company Name> Ltd.
 *  All Rights Reserved
 *
 *  The information herein is confidential and proprietary.  Unauthorised
 *  disclosure or distribution is prohibited.
 */
/*!
 * \file
 * \brief
 *      One line description of the file. Must make sense on it own
 *
 *      Continuation of the description into more detail if required.
 *
 * \version   0.0.1
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>

#include "linked_list.h"

/*!
 * \brief
 *    One line description of the function. Must make sense on it own
 *
 *    Continuation of the description into more detail if required.
 *
 * \return  OK on success
 *          NOT_OK on failure
 */
int main(void)
{
    int i;
    for(i=0;i<10;i++) {
        printf("\n%d.\n",i);
        add_to_list(i,true);
        print_list();
    }

    delete_from_list(4);
    print_list();

	return EXIT_SUCCESS;
}
