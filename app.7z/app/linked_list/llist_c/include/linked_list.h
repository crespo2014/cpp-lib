/**
 * @file linked_list.h
 *
 * @date 2 Mar 2015
 * @author dragan
 */

#ifndef APP_LINKED_LIST_INCLUDE_LINKED_LIST_H_
#define APP_LINKED_LIST_INCLUDE_LINKED_LIST_H_

struct llist {
    int val;
    struct llist *next;
};

typedef struct llist llist_t;



/*!
 * \brief
 *    One line description of the function. Must make sense on it own
 *
 *    Continuation of the description into more detail if required.
 *
 * \param   parameter description
 * \return  OK on success
 *          NOT_OK on failure
 */
llist_t *create_list(int val);

/*!
 * \brief
 *    One line description of the function. Must make sense on it own
 *
 *    Continuation of the description into more detail if required.
 *
 * \param   parameter description
 * \return  OK on success
 *          NOT_OK on failure
 */
llist_t *add_to_list(int val, bool add_to_end);

/*!
 * \brief
 *    One line description of the function. Must make sense on it own
 *
 *    Continuation of the description into more detail if required.
 *
 * \param   parameter description
 * \return  OK on success
 *          NOT_OK on failure
 */
llist_t *search_list(int val, llist_t **prev);

/*!
 * \brief
 *    One line description of the function. Must make sense on it own
 *
 *    Continuation of the description into more detail if required.
 *
 * \param   parameter description
 * \return  OK on success
 *          NOT_OK on failure
 */
int delete_from_list(int val);

/*!
 * \brief
 *    One line description of the function. Must make sense on it own
 *
 *    Continuation of the description into more detail if required.
 *
 * \param   parameter description
 * \return  OK on success
 *          NOT_OK on failure
 */
void print_list(void);


llist_t *get_head(void);
void set_head(llist_t *a);
llist_t *get_current(void);
void set_current(llist_t *a);


#endif /* APP_LINKED_LIST_INCLUDE_LINKED_LIST_H_ */
