/*
 * Copyright (C) 2013 Dragan Cvetic. All rights reserved.
 *
 * This program is open source software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * Alternatively, this program may be distributed and modified under the
 * terms of Quantum Leaps commercial licenses, which expressly supersede
 * the GNU General Public License and are specifically designed for
 * licensees interested in retaining the proprietary status of their code.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Contact information:
 * --------------------
 * e-mail:      dragan.m.cvetic@gmail.com
 */
/*!
 * \file
 * \brief
 *      One line description of the file. Must make sense on it own
 *
 *      Continuation of the description into more detail if required.
 *
 * \version   0.0.1
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <pthread.h>
#include "linked_list.h"

static llist_t *head=NULL, *current=NULL;
static pthread_mutex_t mutex;

llist_t *create_list(int val)
{
    llist_t *ptr = (llist_t *)malloc(sizeof(llist_t));

    if(ptr == NULL) {
//        printf("\nMemory allocation failure\n");
        return NULL;
    }

    ptr->val = val;
    ptr->next = NULL;

    pthread_mutex_lock(&mutex);
    head = current = ptr;
    pthread_mutex_unlock(&mutex);

	return ptr;
}

llist_t *add_to_list(int val, bool add_to_end)
{
    llist_t *ptr;

    if(head == NULL) {
        return create_list(val);
    }

    ptr = (llist_t *)malloc(sizeof(llist_t));
    if(ptr == NULL) {
//        printf("\nMemory allocation failure\n");
        return NULL;
    }

    ptr->val = val;
    ptr->next = NULL;

    pthread_mutex_lock(&mutex);
    if(add_to_end == true) {
        current->next = ptr;
        current = ptr;
    } else {
        ptr->next = head;
        head = ptr;
    }
    pthread_mutex_unlock(&mutex);

    return ptr;
}

llist_t *search_list(int val, llist_t **prev)
{
    llist_t *ptr = head, *tmp=NULL;
    *prev = NULL;

    if(ptr == NULL) {
//        printf("\nList does not exist\n");
        return NULL;
    }

    pthread_mutex_lock(&mutex);
    while(ptr != NULL) {
        if(ptr->val == val) {
            *prev = tmp;
            pthread_mutex_unlock(&mutex);
            return ptr;
        }
        tmp = ptr;
        ptr = ptr->next;
    }
    pthread_mutex_unlock(&mutex);


    return NULL;
}

int delete_from_list(int val)
{
    llist_t *prev=NULL, *del=NULL;

    pthread_mutex_lock(&mutex);
    del = search_list(val,&prev);

    if(del == NULL) {
        pthread_mutex_unlock(&mutex);
        return -1;
    } else {
        if(prev != NULL) {
            prev->next = del->next;
        }
        if(del == current) {
            prev->next = NULL;
            current = prev;
        } else if(del == head) {
            head = head->next;
        }
    }
    pthread_mutex_unlock(&mutex);

    free(del);
    return 0;
}

void print_list(void)
{
    llist_t *tmp=head;
//    int i=0;
    if(tmp == NULL) {
        return;
    }
//    printf("\n---------- List START -------------\n");
    while(tmp != NULL) {
//        printf("%d. val=%d, next=%lld\n", i++, tmp->val, (long long int)tmp->next);
        tmp = tmp->next;
    }
//    printf("---------- List END ---------------\n");
}

llist_t *get_head(void) {
    return head;
}
void set_head(llist_t *a) {
    head=a;
}
llist_t *get_current(void) {
    return current;
}
void set_current(llist_t *a) {
    current=a;
}
