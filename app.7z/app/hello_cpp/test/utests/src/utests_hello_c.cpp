typedef int int32_t;

/***************** Includes ***************************************************/
/* other component PUBLIC header files */
#include "CppUTest/TestHarness.h"
#include "CppUTestExt/MockSupport.h"
//#include "CppUTest/SystemAssertPlugin.h"

/* standard libraries */
#include <stdio.h>

/* CPP Includes Under Test */
#include "test_01.h"
#include "test_02.h"

/***************** Mocks ******************************************************/
int printf (__const char *__restrict __format, ...){
    (void)__format;
    mock().actualCall("printf");
    return mock().returnIntValueOrDefault(0xaa55);
}

/***************** Defines ****************************************************/

/***************** Public Functions Definitions *******************************/

TEST_GROUP(hello_cpp) {

    void setup() {
        mock().enable();
    }

    void teardown()	{
        mock().clear();
    }
};

TEST(hello_cpp, lib_01)
{
    mock().expectNCalls(10,"printf").andReturnValue(0);
    CHECK(30 == test_01(13) );
    mock().checkExpectations();

    mock().expectNCalls(3,"printf").andReturnValue(0);
    mock().ignoreOtherCalls();
    CHECK(23 == test_01(3) );
    mock().checkExpectations();
}
TEST(hello_cpp, lib_02)
{
    mock().expectNCalls(10,"printf").andReturnValue(0xaa55);
    mock().ignoreOtherCalls();
    CHECK(30 == test_02(13) );
    mock().checkExpectations();

    mock().expectNCalls(3,"printf").andReturnValue(0xaa55);
    mock().ignoreOtherCalls();
    CHECK(23 == test_02(3) );
    mock().checkExpectations();
}

