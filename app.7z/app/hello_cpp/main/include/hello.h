/*
 *  Copyright (c) 2006-2012
 *  <Company Name> Ltd.
 *  All Rights Reserved
 *
 *  The information herein is confidential and proprietary.  Unauthorised
 *  disclosure or distribution is prohibited.
 */
/*!
 * \file
 * \brief
 *      One line description of the file. Must make sense on it own
 *
 *      Continuation of the description into more detail if required.
 *
 * \version   0.0.1
 */
#ifndef HELLO_H_
#define HELLO_H_

#endif                                                  /* HELLO_H_ */
