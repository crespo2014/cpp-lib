/*
 *  Copyright (c) 2006-2012
 *  <Company Name> Ltd.
 *  All Rights Reserved
 *
 *  The information herein is confidential and proprietary.  Unauthorised
 *  disclosure or distribution is prohibited.
 */
/*!
 * \file
 * \brief
 *      One line description of the file. Must make sense on it own
 *
 *      Continuation of the description into more detail if required.
 *
 * \version   0.0.1
 */
#include <cstdio>
#include <cstdlib>


static void f1();
static void f2();
static void f3();
static void f4();
static void f5();


#include <iostream>
#include <map>
#include <string>

class RestRequestKey {
private:
public:
    std::string uri_;
    std::string method_;
    RestRequestKey(std::string uri, std::string method) : uri_(uri), method_(method) {
    }

    bool operator< (const RestRequestKey &b) const {
        if(uri_ < b.uri_) {
            return true;
        }
        if(uri_ > b.uri_) {
            return false;
        }
        return(method_ < b.method_);
    }
};

typedef void(*fptr)();

class RestRequest {
private:
public:
    fptr f_;
    int val_;
    RestRequest (fptr f=f1, int val=3) : f_(f), val_(val) {}
};

void test_map3()
{
    std::map<RestRequestKey, RestRequest> map1;

    RestRequestKey a1("/rest/data1","GET");
    RestRequestKey a2("/rest/data1","PUT");
    RestRequestKey a3("/rest/data2","GET");
    RestRequestKey a4("/rest/data2","PUT");
    RestRequestKey a5("/rest/data4","PUT");
    RestRequest r1(f1,123);
    RestRequest r2(f2,245);
    RestRequest r3(f3,245);
    RestRequest r4(f4,245);
    RestRequest r5(f5,245);

    map1[a1] = r1;
    map1[a2] = r2;
    map1[a3] = r3;
    map1[a4] = r4;
    map1[a5] = r5;

    map1.find(a3)->second.f_();
    map1.find(a1)->second.f_();
    map1.find(a5)->second.f_();
    std::cout << map1.find(a5)->first.uri_ << std::endl;

}

static void f1()
{
    std::cout << "Hello 1" << std::endl;
}
static void f2()
{
    std::cout << "Hello 2" << std::endl;
}
static void f3()
{
    std::cout << "Hello 3" << std::endl;
}

static void f4()
{
    std::cout << "Hello 4" << std::endl;
}

static void f5()
{
    std::cout << "Hello 5" << std::endl;
}

