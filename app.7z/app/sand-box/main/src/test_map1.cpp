
#include <iostream>
#include <map>
#include <string>

class RestRequestKey {
private:
    std::string uri_;
    std::string method_;
public:
    RestRequestKey(std::string uri, std::string method) : uri_(uri), method_(method) {
    }

    bool operator< (const RestRequestKey &b) const {
        if(uri_ < b.uri_) {
            return true;
        }
        if(uri_ > b.uri_) {
            return false;
        }
        return(method_ < b.method_);
    }
};

void test_map1()
{
    std::map<RestRequestKey, int> map1;
    map1[RestRequestKey("/rest/data1","GET")] = 11;
    map1[RestRequestKey("/rest/data1","PUT")] = 12;
    map1[RestRequestKey("/rest/data1","POST")] = 13;
    map1[RestRequestKey("/rest/data1","DELETE")] = 14;
    map1[RestRequestKey("/rest/data2","GET")] = 21;
    map1[RestRequestKey("/rest/data2","PUT")] = 22;
    map1[RestRequestKey("/rest/data2","POST")] = 23;
    map1[RestRequestKey("/rest/data2","DELETE")] = 24;

    std::cout << map1.find(RestRequestKey("/rest/data2","DELETE"))->second << std::endl;
    std::cout << map1.find(RestRequestKey("/rest/data1","DELETE"))->second << std::endl;
    std::cout << map1.find(RestRequestKey("/rest/data2","DELETE"))->second << std::endl;
    std::cout << map1.find(RestRequestKey("/rest/data2","PUT"))->second << std::endl;

    RestRequestKey a("/rest/1data1","GET");
    RestRequestKey b("/rest/1data1","PUT");
    RestRequestKey c("/rest/1data1","POST");
    RestRequestKey d("/rest/1data1","DELETE");
    RestRequestKey e("/rest/2data2","GET");
    RestRequestKey f("/rest/2data2","PUT");
    RestRequestKey g("/rest/2data2","POST");
    RestRequestKey h("/rest/2data2","DELETE");

    map1[a] = 11;
    map1[b] = 12;
    map1[c] = 13;
    map1[d] = 14;
    map1[e] = 21;
    map1[f] = 22;
    map1[g] = 23;
    map1[h] = 24;

    std::cout << map1.find(d)->second << std::endl;
    std::cout << map1.find(f)->second << std::endl;
    std::cout << map1.find(g)->second << std::endl;
    std::cout << map1.find(a)->second << std::endl;
}
