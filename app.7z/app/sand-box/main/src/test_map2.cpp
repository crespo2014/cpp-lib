
#include <iostream>
#include <map>
#include <string>

class RestRequestKey {
private:
    std::string uri_;
    std::string method_;
public:
    RestRequestKey(std::string uri, std::string method) : uri_(uri), method_(method) {
    }

    bool operator< (const RestRequestKey &b) const {
        if(uri_ < b.uri_) {
            return true;
        }
        if(uri_ > b.uri_) {
            return false;
        }
        return(method_ < b.method_);
    }
};

class RestRequest {
private:
public:
    int val_;
    RestRequest (int val=3) : val_(val) {}
};

void test_map2()
{
    std::map<RestRequestKey, RestRequest> map1;

    RestRequestKey a("/rest/data","GET");
    RestRequestKey b("/rest/data","PUT");
    RestRequest r1(123);
    RestRequest r2(245);

    map1[a] = r1;
    map1[b] = r2;

    std::cout << map1.find(b)->second.val_ << std::endl;
    std::cout << map1.find(a)->second.val_ << std::endl;
    std::cout << map1.find(a)->second.val_ << std::endl;
    std::cout << map1.find(a)->second.val_ << std::endl;
}
