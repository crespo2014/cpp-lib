/*
 *  Copyright (c) 2006-2012
 *  <Company Name> Ltd.
 *  All Rights Reserved
 *
 *  The information herein is confidential and proprietary.  Unauthorised
 *  disclosure or distribution is prohibited.
 */
/*!
 * \file
 * \brief
 *      One line description of the file. Must make sense on it own
 *
 *      Continuation of the description into more detail if required.
 *
 * \version   0.0.1
 */
#include <cstdio>
#include <cstdlib>



extern void test_map1();
extern void test_map2();
extern void test_map3();
extern void test_map4();

int main(void)
{
    test_map4();
    return EXIT_SUCCESS;
}
