/*
 *  Copyright (c) 2006-2012
 *  <Company Name> Ltd.
 *  All Rights Reserved
 *
 *  The information herein is confidential and proprietary.  Unauthorised
 *  disclosure or distribution is prohibited.
 */
/*!
 * \file
 * \brief
 *      One line description of the file. Must make sense on it own
 *
 *      Continuation of the description into more detail if required.
 *
 * \version   0.0.1
 */
#include <cstdio>
#include <cstdlib>


static void f1();
static void f2();
static void f3();
static void f4();
static void f5();


#include <iostream>
#include <map>
#include <string>

class RestRequestKey {
private:
    friend class RestRequestKeyTest;
    std::string uri_;
    std::string method_;
public:
    RestRequestKey(std::string uri, std::string method) : uri_(uri), method_(method) {
    }

    bool operator< (const RestRequestKey &b) const {
        if(uri_ < b.uri_) {
            return true;
        }
        if(uri_ > b.uri_) {
            return false;
        }
        return(method_ < b.method_);
    }
};

class RestRequestKeyTest {
public:
    std::string GetUri(RestRequestKey &r) {
        return r.uri_;
    }
    std::string GetMethod(RestRequestKey &r) {
        return r.method_;
    }
};

typedef void(*fptr)();

class RestRequest {
private:
    friend class RestRequestTest;
    fptr f_;
    int val_;
public:
    RestRequest (fptr f=f1, int val=3) : f_(f), val_(val) {}
};
class RestRequestTest {
public:
    fptr GetFunction(RestRequest &r) {
        return r.f_;
    }
    int GetVal(RestRequest &r) {
        return r.val_;
    }
};

void test_map5()
{
    std::map<RestRequestKey, RestRequest> map1;
    RestRequestKeyTest kt;
    RestRequestTest t;

    //std::pair<RestRequestKey,RestRequest> b;
    RestRequestKey *a;
    RestRequest *r;

    map1[RestRequestKey("/rest/data1","GET")] = RestRequest(f1,123);
    map1[RestRequestKey("/rest/data1","PUT")] = RestRequest(f2,245);
    map1[RestRequestKey("/rest/data2","GET")] = RestRequest(f3,345);
    map1[RestRequestKey("/rest/data2","PUT")] = RestRequest(f4,445);
    map1[RestRequestKey("/rest/data4","PUT")] = RestRequest(f5,545);

    a = (RestRequestKey*)&map1.find(RestRequestKey("/rest/data1","GET"))->first;
    auto it = map1.find(RestRequestKey("/rest/data1","GET"));
    std::pair<const RestRequestKey,RestRequest> &b = *it;
//    r = (RestRequest*)&map1.find(a3)->second;
//    std::cout << kt.GetUri(*a) << " - " << kt.GetMethod(*a) << " - " << t.GetVal(*r) << std::endl;
    t.GetFunction(*r)();
}

static void f1()
{
    std::cout << "Hello 1" << std::endl;
}
static void f2()
{
    std::cout << "Hello 2" << std::endl;
}
static void f3()
{
    std::cout << "Hello 3" << std::endl;
}

static void f4()
{
    std::cout << "Hello 4" << std::endl;
}

static void f5()
{
    std::cout << "Hello 5" << std::endl;
}

