/*
 * CRestServer_test.cpp
 *
 *  Created on: 24 Feb 2015
 *      Author: dragan
 */


/***************** Includes ***************************************************/
/* other component PUBLIC header files */
#include "CppUTest/TestHarness.h"
#include "CppUTestExt/MockSupport.h"
//#include "CppUTest/SystemAssertPlugin.h"

/* CPP Includes Under Test */
#include "CRestRequest.h"

using namespace rest;

/***************** Mocks ******************************************************/

/***************** Defines ****************************************************/

/***************** Public Functions Definitions *******************************/

TEST_GROUP(rest_request) {

    void setup() {
    }

    void teardown() {
    }
};

TEST(rest_request, CRestRequest)
{
    CRestRequest r;
    CRestRequestTest t;
    string s = "empty";

    CHECK_EQUAL(t.GetUri(r), s);
}

