/*
 * CRestServer_test.cpp
 *
 *  Created on: 24 Feb 2015
 *      Author: dragan
 */


/***************** Includes ***************************************************/
/* other component PUBLIC header files */
#include "CppUTest/TestHarness.h"
#include "CppUTestExt/MockSupport.h"
//#include "CppUTest/SystemAssertPlugin.h"

/* CPP Includes Under Test */
#include "CRestServer.h"

using namespace rest;

/***************** Mocks ******************************************************/

/***************** Defines ****************************************************/

/***************** Public Functions Definitions *******************************/

TEST_GROUP(rest_server) {

    void setup() {
    }

    void teardown() {
    }
};

TEST(rest_server, CRestServer)
{
    CRestServer r;
}

