/*
 * CRestServer.h
 *
 *  Created on: 24 Feb 2015
 *      Author: dragan
 */

#ifndef CRESTSERVER_H_
#define CRESTSERVER_H_

extern "C" {
#include <sys/types.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <microhttpd.h>
}

#include <string>
#include<map>

#include "CRestRequest.h"

using namespace std;

#define PORT 8888

namespace rest {

class CRestServer {
private:
    friend class CRestServerTest;
//    void StartDaemon(bool &);
//    void StopDaemon();
//    int RestServerCB (void *cls,
//                      struct MHD_Connection *connection,
//                      const char *url,
//                      const char *method,
//                      const char *version,
//                      const char *upload_data,
//                      size_t *upload_data_size,
//                      void **con_cls);

    struct MHD_Daemon *daemon;
    static bool DaemonStarted;

public:
    map <string,method_e> method_map;
    CRestServer();
    virtual ~CRestServer();
};


class CRestServerTest {
public:
};
} /* namespace rest */

#endif /* CRESTSERVER_H_ */
