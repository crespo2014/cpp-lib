/*
 * CRestRequest.h
 *
 *  Created on: 8 Mar 2015
 *      Author: dragan
 */

#ifndef CRESTREQUEST_H_
#define CRESTREQUEST_H_

#include <string>
#include<map>
using namespace std;

typedef void (*fptr)();
enum method_e {GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS};

namespace rest {

class CRestRequest {
private:
    friend class CRestRequestTest;
    string uri;
    method_e method_;
    fptr f;

public:
    CRestRequest();
    virtual ~CRestRequest();
    int RegisterRequest();
};


class CRestRequestTest {
public:
    string GetUri(CRestRequest &r) {
        return r.uri;
    }
    method_e GetMethod(CRestRequest &r) {
        return r.method_;
    }
    fptr GetFun(CRestRequest &r) {
        return r.f;
    }
};
} /* namespace rest */

#endif /* CRESTREQUEST_H_ */
