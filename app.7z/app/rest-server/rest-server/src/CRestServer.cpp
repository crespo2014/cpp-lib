/*
 * CRestServer.cpp
 *
 *  Created on: 24 Feb 2015
 *      Author: dragan
 */

#include "CRestServer.h"

namespace rest {

#if 0
void CRestServer::StartDaemon(bool &)
{
}
void CRestServer::StopDaemon()
{
}

int CRestServer::RestServerCB (void *cls,
                  struct MHD_Connection *connection,
                  const char *url,
                  const char *method,
                  const char *version,
                  const char *upload_data,
                  size_t *upload_data_size,
                  void **con_cls)
{
    return 0;
}
#endif

CRestServer::CRestServer() {
//    StartDaemon(DaemonStarted);

    (void)method_map.insert(pair<string,method_e>("GET",GET));
    (void)method_map.insert(pair<string,method_e>("HEAD",HEAD));
    (void)method_map.insert(pair<string,method_e>("POST",POST));
    (void)method_map.insert(pair<string,method_e>("PUT",PUT));
    (void)method_map.insert(pair<string,method_e>("PATCH",PATCH));
    (void)method_map.insert(pair<string,method_e>("DELETE",DELETE));
    (void)method_map.insert(pair<string,method_e>("OPTIONS",OPTIONS));
}

CRestServer::~CRestServer() {
//    StopDaemon();
    method_map.erase(method_map.begin(), method_map.end());
}

} /* namespace rest */
