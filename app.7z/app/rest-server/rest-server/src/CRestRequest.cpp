/*
 * CRestRequest.cpp
 *
 *  Created on: 8 Mar 2015
 *      Author: dragan
 */

#include "CRestRequest.h"

namespace rest {

CRestRequest::CRestRequest() {
    uri = "empty";
    method_ = PATCH;
    f = nullptr;    //lint !e40
}

CRestRequest::~CRestRequest() {
}

int RegisterRequest() {
    return 0;
}

} /* namespace rest */
