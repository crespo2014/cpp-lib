//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by neurofb.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_NEUROFTYPE                  129
#define ID_PATIENT_NEWPATIENT           32774
#define ID_PATIENT_PATIENTOPTIONS       32776
#define ID_SESSION_SESSIONSETTINGS      32777
#define ID_SESSION_STARTSESSION         32778
#define ID_PATIENT_SHOWPATIENTDATA      32779
#define ID_OPTIONS_PRINTSESSION         32780
#define ID_OPTIONS_GRAPHICS             32781
#define ID_SESSION_SHOWALLSESSIONSREPORTS 32782
#define ID_SESSION_NEWSESION            32787
#define ID_SESSION_NEWSESSION           32793
#define CHANGEPASSWORD                  32794

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32795
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
