//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by neurofbdll.rc
//
#define IDB_NOPACIENT                   130
#define IDB_SESSION                     131
#define IDB_CONDITION                   132
#define IDB_MINUTE                      133
#define IDB_PACIENT                     134
#define IDC_PASSWORD                    1000
#define IDD_BUSCARPACIENTE              1000
#define IDD_MOSTRARDATOS                1001
#define IDC_GRIDMINUTOS                 1001
#define IDC_MSFLEXGRID1                 1001
#define IDD_CONFIGURARSESION            1002
#define IDC_TREEPACIENTE                1002
#define IDD_CONDICION                   1003
#define IDC_EDITSESSIONDATE             1003
#define No_Paciente                     1003
#define IDC_EDITSESSIONREPORT           1004
#define Nombre_Paciente                 1004
#define IDC_EDIT_NUEVA                  1004
#define IDC_EDITDURACIONCONDICION       1005
#define Apellido_Paciente               1005
#define IDD_REGISTRO                    1005
#define IDC_EDIT_REESCRIBIR             1005
#define IDD_PASSWORD                    1006
#define IDC_EDITNIVELINHIBICIONEEG      1006
#define IDC_REJILLA                     1006
#define Fecha_Nacimiento                1006
#define IDC_EDITNIVELREWARDEEG          1007
#define IDC_ADD                         1007
#define Telefono                        1007
#define IDC_EDITNIVELINHIBICIONMUSCULO  1008
#define IDC_DELETE                      1008
#define IDC_EDITREPORTS                 1008
#define Direccion                       1008
#define IDC_EDITCRITERIOCOMPARACIONBURST 1009
#define IDC_UPDATE                      1009
#define IDD_REPORTES                    1009
#define Diagnostico                     1009
#define IDC_EDITTIEMPOCONTEOBURST       1010
#define Medicacion_Actual               1010
#define PASSWORD                        1010
#define IDC_EDITBFINHIBICIONEEG         1011
#define IDC_COMBOILOWFREQ               1011
#define IDC_EDITTEMPERATURA             1012
#define IDC_EDITAFINHIBICIONEEG         1013
#define IDC_TODOS                       1013
#define IDC_COMBORLOWFREQ               1013
#define IDC_EDITBFREWARDEEG             1014
#define IDC_NOMBRE                      1014
#define IDC_COMBOIHIGHFREQ              1014
#define IDC_EDITAFREWARDEEG             1015
#define IDC_BUSCA_TODOS                 1015
#define IDC_COMBORHIGHFREQ              1015
#define IDC_BUSCAR_PACIENTE             1016
#define IDC_COMBOMUSCLEFREQ             1016
#define IDC_EDITAFMUSCLEFREG            1016
#define IDC_ID                          1017
#define IDC_NAME                        1018
#define IDC_CARGA_PACIENTE              1019
#define IDC_BORRA_PACIENTE              1020
#define IDC_IMPORTA_PACIENTE            1021
#define IDC_EXPORTA_PACIENTE            1022
#define IDC_ACTUALIZAR_PACIENTE         1023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1011
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           1000
#endif
#endif
